﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OsLab_Algorithms
{
    public partial class frmOsAlgorithm : Form
    {
        public frmOsAlgorithm()
        {
            InitializeComponent();
        }


        private void btnFCFS_Click(object sender, EventArgs e)
        {
            decimal a1, a2, a3, a4, a5, b1, b2, b3, b4, b5;
            a1 = Convert.ToDecimal(txtAT1.Text); a2 = Convert.ToDecimal(txtAT2.Text); a3 = Convert.ToDecimal(txtAT3.Text); a4 = Convert.ToDecimal(txtAT4.Text);
            a5 = Convert.ToDecimal(txtAT5.Text); b1 = Convert.ToDecimal(txtBT1.Text); b2 = Convert.ToDecimal(txtBT2.Text); b3 = Convert.ToDecimal(txtBT3.Text);
            b4 = Convert.ToDecimal(txtBT4.Text); b5 = Convert.ToDecimal(txtBT5.Text);


            decimal[][] arrayprocess = new decimal[][] { new decimal[] { a1, b1 }, new decimal[] { a2, b2 }, new decimal[] { a3, b3 }, new decimal[] { a4, b4 }, new decimal[] { a5, b5 } };

            var arvl1 = arrayprocess[0][0];
            var arvl2 = arrayprocess[1][0];
            var arvl3 = arrayprocess[2][0];
            var arvl4 = arrayprocess[3][0];
            var arvl5 = arrayprocess[4][0];

            var brst1 = arrayprocess[0][1];
            var brst2 = arrayprocess[1][1];
            var brst3 = arrayprocess[2][1];
            var brst4 = arrayprocess[3][1];
            var brst5 = arrayprocess[4][1];



            #region FCFS
            var ct1 = brst1;
            var ct2 = ct1 + brst2;
            var ct3 = ct2 + brst3;
            var ct4 = ct3 + brst4;
            var ct5 = ct4 + brst5;

            var wt1 = arvl1;
            var wt2 = ct1 - arvl2;
            var wt3 = ct2 - arvl3;
            var wt4 = ct3 - arvl4;
            var wt5 = ct4 - arvl5;

            //Sort(arrayprocess, 0);

            
            label8.Text = arvl1 + " " + arvl2 + " " + arvl3 + " " + arvl4 + " " + arvl5;
            label9.Text = brst1 + " " + brst2 + " " + brst3 + " " + brst4 + " " + brst5;
            decimal totalburst = brst1 + brst2 + brst3 + brst4 + brst5;
            label10.Text = Convert.ToString(totalburst);


            #region Graphics
            ////Gantt Chart
            //Graphics dc = this.CreateGraphics();
            //Pen Bluepen = new Pen(Color.Blue, 3);
            //dc.DrawRectangle(Bluepen, 50, 200, Convert.ToInt32(brst1) * 10, 20);
            //Pen Redpen = new Pen(Color.Red, 3);
            //dc.DrawRectangle(Redpen, 50 + Convert.ToInt32(brst1) * 10, 200, Convert.ToInt32(brst2) * 10, 20);
            //Pen Yellowpen = new Pen(Color.Yellow, 3);
            //dc.DrawRectangle(Yellowpen, 50 + Convert.ToInt32(brst1) * 10 + Convert.ToInt32(brst2) * 10, 200, Convert.ToInt32(brst3) * 10, 20);
            //Pen Greenpen = new Pen(Color.Green, 3);
            //dc.DrawRectangle(Greenpen, 50 + Convert.ToInt32((brst1 + brst2 + brst3)) * 10, 200, Convert.ToInt32(brst4) * 10, 20);
            //Pen Violetpen = new Pen(Color.Violet, 3);
            //dc.DrawRectangle(Violetpen, 50 + Convert.ToInt32((brst1 + brst2 + brst3 + brst4)) * 10, 200, Convert.ToInt32(brst5) * 10, 20); 
            #endregion


            lblWT1.Text = wt1.ToString();
            lblWT2.Text = wt2.ToString();
            lblWT3.Text = wt3.ToString();
            lblWT4.Text = wt4.ToString();
            lblWT5.Text = wt5.ToString();

            var avgWt = Convert.ToDecimal(Convert.ToDecimal(wt1 + wt2 + wt3 + wt4 + wt5) / 5);
            lblAvgWt.Text = avgWt.ToString();

            var tat1 = ct1 - arvl1;
            var tat2 = ct2 - arvl2;
            var tat3 = ct3 - arvl3;
            var tat4 = ct4 - arvl4;
            var tat5 = ct5 - arvl5;

            lblTAT1.Text = tat1.ToString();
            lblTAT2.Text = tat2.ToString();
            lblTAT3.Text = tat3.ToString();
            lblTAT4.Text = tat4.ToString();
            lblTAT5.Text = tat5.ToString();

            var avgTat = Convert.ToDecimal(Convert.ToDecimal(tat1 + tat2 + tat3 + tat4 + tat5) / 5);
            lblAvgTat.Text = avgTat.ToString();




            lblCT1.Text = ct1.ToString();
            lblCT2.Text = ct2.ToString();
            lblCT3.Text = ct3.ToString();
            lblCT4.Text = ct4.ToString();
            lblCT5.Text = ct5.ToString();

            lblBT1.Text = Convert.ToString(brst1);
            lblBT2.Text = Convert.ToString(brst2);
            lblBT3.Text = Convert.ToString(brst3);
            lblBT4.Text = Convert.ToString(brst4);
            lblBT5.Text = Convert.ToString(brst5);

            lblAT1.Text = Convert.ToString(arvl1);
            lblAT2.Text = Convert.ToString(arvl2);
            lblAT3.Text = Convert.ToString(arvl3);
            lblAT4.Text = Convert.ToString(arvl4);
            lblAT5.Text = Convert.ToString(arvl5);

            lblP1.Text = "1";
            lblP2.Text = "2";
            lblP3.Text = "3";
            lblP4.Text = "4";
            lblP5.Text = "5"; 
            #endregion



        }
        public void Sort<T>(T[][] data, int col)
        {
            Comparer<T> comparer = Comparer<T>.Default;
            Array.Sort<T[]>(data, (x, y) => comparer.Compare(x[col], y[col]));
        }


        private void btnSJF_Click(object sender, EventArgs e)
        {
            decimal a1, a2, a3, a4, a5, b1, b2, b3, b4, b5;
            a1 = Convert.ToDecimal(txtAT1.Text); a2 = Convert.ToDecimal(txtAT2.Text); a3 = Convert.ToDecimal(txtAT3.Text); a4 = Convert.ToDecimal(txtAT4.Text);
            a5 = Convert.ToDecimal(txtAT5.Text); b1 = Convert.ToDecimal(txtBT1.Text); b2 = Convert.ToDecimal(txtBT2.Text); b3 = Convert.ToDecimal(txtBT3.Text);
            b4 = Convert.ToDecimal(txtBT4.Text); b5 = Convert.ToDecimal(txtBT5.Text);


            decimal[][] arrayprocess = new decimal[][] { new decimal[] { a1, b1 }, new decimal[] { a2, b2 }, new decimal[] { a3, b3 }, new decimal[] { a4, b4 }, new decimal[] { a5, b5 } };

            var arvl1 = arrayprocess[0][0];
            var arvl2 = arrayprocess[1][0];
            var arvl3 = arrayprocess[2][0];
            var arvl4 = arrayprocess[3][0];
            var arvl5 = arrayprocess[4][0];

            var brst1 = arrayprocess[0][1];
            var brst2 = arrayprocess[1][1];
            var brst3 = arrayprocess[2][1];
            var brst4 = arrayprocess[3][1];
            var brst5 = arrayprocess[4][1];

            //Sort(arrayprocess, 1);
            decimal[][] ATsortedArray = arrayprocess.OrderBy(x => x[0]).ToArray();


            decimal[][] restArray = arrayprocess.Where((arr, i) => i != 0).ToArray(); //skipped row#1


            decimal[][] BTsortedArray = restArray.OrderBy(x => x[1]).ToArray();

            


            #region FCFS
            var ct1 = ATsortedArray[0][0] + ATsortedArray[0][1];

            var ct2 = ct1 + BTsortedArray[0][1];
            var ct3 = ct2 + BTsortedArray[1][1];
            var ct4 = ct3 + BTsortedArray[2][1];
            var ct5 = ct4 + BTsortedArray[3][1];

            //decimal[][] ctArray = new decimal[][] {
            //    new decimal[] { restArray[0][0], yourArray.Any(x=> x.Any(y=> y == 3))},
            //    new decimal[] { restArray[1][0], b2 },
            //    new decimal[] { restArray[2][0], b3 },
            //    new decimal[] { restArray[3][0], b4 },
            //};

            var wt1 = arvl1;
            var wt2 = ct1 - arvl2;
            var wt3 = ct2 - arvl3;
            var wt4 = ct3 - arvl4;
            var wt5 = ct4 - arvl5;

            //Sort(arrayprocess, 0);


            label8.Text = arvl1 + " " + arvl2 + " " + arvl3 + " " + arvl4 + " " + arvl5;
            label9.Text = brst1 + " " + brst2 + " " + brst3 + " " + brst4 + " " + brst5;
            decimal totalburst = brst1 + brst2 + brst3 + brst4 + brst5;
            label10.Text = Convert.ToString(totalburst);


            lblWT1.Text = wt1.ToString();
            lblWT2.Text = wt2.ToString();
            lblWT3.Text = wt3.ToString();
            lblWT4.Text = wt4.ToString();
            lblWT5.Text = wt5.ToString();

            var avgWt = Convert.ToDecimal(Convert.ToDecimal(wt1 + wt2 + wt3 + wt4 + wt5) / 5);
            lblAvgWt.Text = avgWt.ToString();

            var tat1 = ct1 - arvl1;
            var tat2 = ct2 - arvl2;
            var tat3 = ct3 - arvl3;
            var tat4 = ct4 - arvl4;
            var tat5 = ct5 - arvl5;

            lblTAT1.Text = tat1.ToString();
            lblTAT2.Text = tat2.ToString();
            lblTAT3.Text = tat3.ToString();
            lblTAT4.Text = tat4.ToString();
            lblTAT5.Text = tat5.ToString();

            var avgTat = Convert.ToDecimal(Convert.ToDecimal(tat1 + tat2 + tat3 + tat4 + tat5) / 5);
            lblAvgTat.Text = avgTat.ToString();




            lblCT1.Text = ct1.ToString();
            lblCT2.Text = ct2.ToString();
            lblCT3.Text = ct3.ToString();
            lblCT4.Text = ct4.ToString();
            lblCT5.Text = ct5.ToString();

            lblBT1.Text = Convert.ToString(brst1);
            lblBT2.Text = Convert.ToString(brst2);
            lblBT3.Text = Convert.ToString(brst3);
            lblBT4.Text = Convert.ToString(brst4);
            lblBT5.Text = Convert.ToString(brst5);

            lblAT1.Text = Convert.ToString(arvl1);
            lblAT2.Text = Convert.ToString(arvl2);
            lblAT3.Text = Convert.ToString(arvl3);
            lblAT4.Text = Convert.ToString(arvl4);
            lblAT5.Text = Convert.ToString(arvl5);

            lblP1.Text = "1";
            lblP2.Text = "2";
            lblP3.Text = "3";
            lblP4.Text = "4";
            lblP5.Text = "5";
            #endregion


        }

        private void frmOsAlgorithm_Load(object sender, EventArgs e)
        {
            
        }
    }
}
