﻿namespace OsLab_Algorithms
{
    partial class frmOsAlgorithm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnFCFS = new System.Windows.Forms.Button();
            this.txtAT1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtBT1 = new System.Windows.Forms.TextBox();
            this.txtBT2 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtAT2 = new System.Windows.Forms.TextBox();
            this.txtBT3 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtAT3 = new System.Windows.Forms.TextBox();
            this.txtBT4 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtAT4 = new System.Windows.Forms.TextBox();
            this.txtBT5 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtAT5 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblWT3 = new System.Windows.Forms.Label();
            this.lblWT2 = new System.Windows.Forms.Label();
            this.lblWT1 = new System.Windows.Forms.Label();
            this.lblWT5 = new System.Windows.Forms.Label();
            this.lblWT4 = new System.Windows.Forms.Label();
            this.lblTAT5 = new System.Windows.Forms.Label();
            this.lblTAT4 = new System.Windows.Forms.Label();
            this.lblTAT3 = new System.Windows.Forms.Label();
            this.lblTAT2 = new System.Windows.Forms.Label();
            this.lblTAT1 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.lblCT5 = new System.Windows.Forms.Label();
            this.lblCT4 = new System.Windows.Forms.Label();
            this.lblCT3 = new System.Windows.Forms.Label();
            this.lblCT2 = new System.Windows.Forms.Label();
            this.lblCT1 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.label15 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.lblBT5 = new System.Windows.Forms.Label();
            this.lblBT4 = new System.Windows.Forms.Label();
            this.lblBT3 = new System.Windows.Forms.Label();
            this.lblBT2 = new System.Windows.Forms.Label();
            this.lblBT1 = new System.Windows.Forms.Label();
            this.lblAT5 = new System.Windows.Forms.Label();
            this.lblAT4 = new System.Windows.Forms.Label();
            this.lblAT3 = new System.Windows.Forms.Label();
            this.lblAT2 = new System.Windows.Forms.Label();
            this.lblAT1 = new System.Windows.Forms.Label();
            this.lblP5 = new System.Windows.Forms.Label();
            this.lblP4 = new System.Windows.Forms.Label();
            this.lblP3 = new System.Windows.Forms.Label();
            this.lblP2 = new System.Windows.Forms.Label();
            this.lblP1 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lblAvgWt = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblAvgTat = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSJF = new System.Windows.Forms.Button();
            this.sorted = new System.Windows.Forms.Button();
            this.row = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnFCFS
            // 
            this.btnFCFS.Location = new System.Drawing.Point(12, 165);
            this.btnFCFS.Name = "btnFCFS";
            this.btnFCFS.Size = new System.Drawing.Size(75, 23);
            this.btnFCFS.TabIndex = 0;
            this.btnFCFS.Text = "FCFS";
            this.btnFCFS.UseVisualStyleBackColor = true;
            this.btnFCFS.Click += new System.EventHandler(this.btnFCFS_Click);
            // 
            // txtAT1
            // 
            this.txtAT1.Location = new System.Drawing.Point(126, 25);
            this.txtAT1.Name = "txtAT1";
            this.txtAT1.Size = new System.Drawing.Size(100, 20);
            this.txtAT1.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(66, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Process 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(140, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Arrival Time";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(276, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Burst Time";
            // 
            // txtBT1
            // 
            this.txtBT1.Location = new System.Drawing.Point(262, 25);
            this.txtBT1.Name = "txtBT1";
            this.txtBT1.Size = new System.Drawing.Size(100, 20);
            this.txtBT1.TabIndex = 4;
            // 
            // txtBT2
            // 
            this.txtBT2.Location = new System.Drawing.Point(262, 51);
            this.txtBT2.Name = "txtBT2";
            this.txtBT2.Size = new System.Drawing.Size(100, 20);
            this.txtBT2.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(66, 54);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Process 1";
            // 
            // txtAT2
            // 
            this.txtAT2.Location = new System.Drawing.Point(126, 51);
            this.txtAT2.Name = "txtAT2";
            this.txtAT2.Size = new System.Drawing.Size(100, 20);
            this.txtAT2.TabIndex = 6;
            // 
            // txtBT3
            // 
            this.txtBT3.Location = new System.Drawing.Point(262, 77);
            this.txtBT3.Name = "txtBT3";
            this.txtBT3.Size = new System.Drawing.Size(100, 20);
            this.txtBT3.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(66, 80);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Process 1";
            // 
            // txtAT3
            // 
            this.txtAT3.Location = new System.Drawing.Point(126, 77);
            this.txtAT3.Name = "txtAT3";
            this.txtAT3.Size = new System.Drawing.Size(100, 20);
            this.txtAT3.TabIndex = 9;
            // 
            // txtBT4
            // 
            this.txtBT4.Location = new System.Drawing.Point(262, 103);
            this.txtBT4.Name = "txtBT4";
            this.txtBT4.Size = new System.Drawing.Size(100, 20);
            this.txtBT4.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(66, 106);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Process 1";
            // 
            // txtAT4
            // 
            this.txtAT4.Location = new System.Drawing.Point(126, 103);
            this.txtAT4.Name = "txtAT4";
            this.txtAT4.Size = new System.Drawing.Size(100, 20);
            this.txtAT4.TabIndex = 12;
            // 
            // txtBT5
            // 
            this.txtBT5.Location = new System.Drawing.Point(262, 129);
            this.txtBT5.Name = "txtBT5";
            this.txtBT5.Size = new System.Drawing.Size(100, 20);
            this.txtBT5.TabIndex = 17;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(66, 132);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(54, 13);
            this.label7.TabIndex = 16;
            this.label7.Text = "Process 1";
            // 
            // txtAT5
            // 
            this.txtAT5.Location = new System.Drawing.Point(126, 129);
            this.txtAT5.Name = "txtAT5";
            this.txtAT5.Size = new System.Drawing.Size(100, 20);
            this.txtAT5.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(293, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(35, 13);
            this.label8.TabIndex = 18;
            this.label8.Text = "label8";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(395, 16);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "label9";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(422, 184);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "label10";
            // 
            // lblWT3
            // 
            this.lblWT3.AutoSize = true;
            this.lblWT3.Location = new System.Drawing.Point(405, 110);
            this.lblWT3.Name = "lblWT3";
            this.lblWT3.Size = new System.Drawing.Size(41, 13);
            this.lblWT3.TabIndex = 23;
            this.lblWT3.Text = "label11";
            // 
            // lblWT2
            // 
            this.lblWT2.AutoSize = true;
            this.lblWT2.Location = new System.Drawing.Point(405, 86);
            this.lblWT2.Name = "lblWT2";
            this.lblWT2.Size = new System.Drawing.Size(41, 13);
            this.lblWT2.TabIndex = 22;
            this.lblWT2.Text = "label12";
            // 
            // lblWT1
            // 
            this.lblWT1.AutoSize = true;
            this.lblWT1.Location = new System.Drawing.Point(405, 63);
            this.lblWT1.Name = "lblWT1";
            this.lblWT1.Size = new System.Drawing.Size(41, 13);
            this.lblWT1.TabIndex = 21;
            this.lblWT1.Text = "label13";
            // 
            // lblWT5
            // 
            this.lblWT5.AutoSize = true;
            this.lblWT5.Location = new System.Drawing.Point(405, 153);
            this.lblWT5.Name = "lblWT5";
            this.lblWT5.Size = new System.Drawing.Size(41, 13);
            this.lblWT5.TabIndex = 25;
            this.lblWT5.Text = "label14";
            // 
            // lblWT4
            // 
            this.lblWT4.AutoSize = true;
            this.lblWT4.Location = new System.Drawing.Point(405, 133);
            this.lblWT4.Name = "lblWT4";
            this.lblWT4.Size = new System.Drawing.Size(41, 13);
            this.lblWT4.TabIndex = 24;
            this.lblWT4.Text = "label15";
            // 
            // lblTAT5
            // 
            this.lblTAT5.AutoSize = true;
            this.lblTAT5.Location = new System.Drawing.Point(352, 153);
            this.lblTAT5.Name = "lblTAT5";
            this.lblTAT5.Size = new System.Drawing.Size(41, 13);
            this.lblTAT5.TabIndex = 30;
            this.lblTAT5.Text = "label16";
            // 
            // lblTAT4
            // 
            this.lblTAT4.AutoSize = true;
            this.lblTAT4.Location = new System.Drawing.Point(352, 133);
            this.lblTAT4.Name = "lblTAT4";
            this.lblTAT4.Size = new System.Drawing.Size(41, 13);
            this.lblTAT4.TabIndex = 29;
            this.lblTAT4.Text = "label17";
            // 
            // lblTAT3
            // 
            this.lblTAT3.AutoSize = true;
            this.lblTAT3.Location = new System.Drawing.Point(352, 110);
            this.lblTAT3.Name = "lblTAT3";
            this.lblTAT3.Size = new System.Drawing.Size(41, 13);
            this.lblTAT3.TabIndex = 28;
            this.lblTAT3.Text = "label18";
            // 
            // lblTAT2
            // 
            this.lblTAT2.AutoSize = true;
            this.lblTAT2.Location = new System.Drawing.Point(352, 86);
            this.lblTAT2.Name = "lblTAT2";
            this.lblTAT2.Size = new System.Drawing.Size(41, 13);
            this.lblTAT2.TabIndex = 27;
            this.lblTAT2.Text = "label19";
            // 
            // lblTAT1
            // 
            this.lblTAT1.AutoSize = true;
            this.lblTAT1.Location = new System.Drawing.Point(352, 63);
            this.lblTAT1.Name = "lblTAT1";
            this.lblTAT1.Size = new System.Drawing.Size(41, 13);
            this.lblTAT1.TabIndex = 26;
            this.lblTAT1.Text = "label20";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(405, 42);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(31, 13);
            this.label11.TabIndex = 31;
            this.label11.Text = "W.T.";
            this.toolTip1.SetToolTip(this.label11, "Waiting Time");
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(352, 42);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 13);
            this.label12.TabIndex = 32;
            this.label12.Text = "T.A.T.";
            this.toolTip1.SetToolTip(this.label12, "Turn Around Time");
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(352, 184);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(64, 13);
            this.label13.TabIndex = 33;
            this.label13.Text = "Total Burst :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(293, 42);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(27, 13);
            this.label14.TabIndex = 39;
            this.label14.Text = "C.T.";
            this.toolTip1.SetToolTip(this.label14, "Completion Time");
            // 
            // lblCT5
            // 
            this.lblCT5.AutoSize = true;
            this.lblCT5.Location = new System.Drawing.Point(293, 153);
            this.lblCT5.Name = "lblCT5";
            this.lblCT5.Size = new System.Drawing.Size(41, 13);
            this.lblCT5.TabIndex = 38;
            this.lblCT5.Text = "label14";
            // 
            // lblCT4
            // 
            this.lblCT4.AutoSize = true;
            this.lblCT4.Location = new System.Drawing.Point(293, 133);
            this.lblCT4.Name = "lblCT4";
            this.lblCT4.Size = new System.Drawing.Size(41, 13);
            this.lblCT4.TabIndex = 37;
            this.lblCT4.Text = "label15";
            // 
            // lblCT3
            // 
            this.lblCT3.AutoSize = true;
            this.lblCT3.Location = new System.Drawing.Point(293, 110);
            this.lblCT3.Name = "lblCT3";
            this.lblCT3.Size = new System.Drawing.Size(41, 13);
            this.lblCT3.TabIndex = 36;
            this.lblCT3.Text = "label11";
            // 
            // lblCT2
            // 
            this.lblCT2.AutoSize = true;
            this.lblCT2.Location = new System.Drawing.Point(293, 86);
            this.lblCT2.Name = "lblCT2";
            this.lblCT2.Size = new System.Drawing.Size(41, 13);
            this.lblCT2.TabIndex = 35;
            this.lblCT2.Text = "label12";
            // 
            // lblCT1
            // 
            this.lblCT1.AutoSize = true;
            this.lblCT1.Location = new System.Drawing.Point(293, 63);
            this.lblCT1.Name = "lblCT1";
            this.lblCT1.Size = new System.Drawing.Size(41, 13);
            this.lblCT1.TabIndex = 34;
            this.lblCT1.Text = "label13";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(235, 42);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(27, 13);
            this.label15.TabIndex = 45;
            this.label15.Text = "B.T.";
            this.toolTip1.SetToolTip(this.label15, "Burst Time");
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(170, 42);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(27, 13);
            this.label21.TabIndex = 51;
            this.label21.Text = "A.T.";
            this.toolTip1.SetToolTip(this.label21, "Arrival Time");
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(106, 42);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(34, 13);
            this.label27.TabIndex = 57;
            this.label27.Text = "P.No.";
            this.toolTip1.SetToolTip(this.label27, "Process");
            // 
            // lblBT5
            // 
            this.lblBT5.AutoSize = true;
            this.lblBT5.Location = new System.Drawing.Point(235, 153);
            this.lblBT5.Name = "lblBT5";
            this.lblBT5.Size = new System.Drawing.Size(41, 13);
            this.lblBT5.TabIndex = 44;
            this.lblBT5.Text = "label14";
            // 
            // lblBT4
            // 
            this.lblBT4.AutoSize = true;
            this.lblBT4.Location = new System.Drawing.Point(235, 133);
            this.lblBT4.Name = "lblBT4";
            this.lblBT4.Size = new System.Drawing.Size(41, 13);
            this.lblBT4.TabIndex = 43;
            this.lblBT4.Text = "label15";
            // 
            // lblBT3
            // 
            this.lblBT3.AutoSize = true;
            this.lblBT3.Location = new System.Drawing.Point(235, 110);
            this.lblBT3.Name = "lblBT3";
            this.lblBT3.Size = new System.Drawing.Size(41, 13);
            this.lblBT3.TabIndex = 42;
            this.lblBT3.Text = "label11";
            // 
            // lblBT2
            // 
            this.lblBT2.AutoSize = true;
            this.lblBT2.Location = new System.Drawing.Point(235, 86);
            this.lblBT2.Name = "lblBT2";
            this.lblBT2.Size = new System.Drawing.Size(41, 13);
            this.lblBT2.TabIndex = 41;
            this.lblBT2.Text = "label12";
            // 
            // lblBT1
            // 
            this.lblBT1.AutoSize = true;
            this.lblBT1.Location = new System.Drawing.Point(235, 63);
            this.lblBT1.Name = "lblBT1";
            this.lblBT1.Size = new System.Drawing.Size(41, 13);
            this.lblBT1.TabIndex = 40;
            this.lblBT1.Text = "label13";
            // 
            // lblAT5
            // 
            this.lblAT5.AutoSize = true;
            this.lblAT5.Location = new System.Drawing.Point(170, 153);
            this.lblAT5.Name = "lblAT5";
            this.lblAT5.Size = new System.Drawing.Size(41, 13);
            this.lblAT5.TabIndex = 50;
            this.lblAT5.Text = "label14";
            // 
            // lblAT4
            // 
            this.lblAT4.AutoSize = true;
            this.lblAT4.Location = new System.Drawing.Point(170, 133);
            this.lblAT4.Name = "lblAT4";
            this.lblAT4.Size = new System.Drawing.Size(41, 13);
            this.lblAT4.TabIndex = 49;
            this.lblAT4.Text = "label15";
            // 
            // lblAT3
            // 
            this.lblAT3.AutoSize = true;
            this.lblAT3.Location = new System.Drawing.Point(170, 110);
            this.lblAT3.Name = "lblAT3";
            this.lblAT3.Size = new System.Drawing.Size(41, 13);
            this.lblAT3.TabIndex = 48;
            this.lblAT3.Text = "label11";
            // 
            // lblAT2
            // 
            this.lblAT2.AutoSize = true;
            this.lblAT2.Location = new System.Drawing.Point(170, 86);
            this.lblAT2.Name = "lblAT2";
            this.lblAT2.Size = new System.Drawing.Size(41, 13);
            this.lblAT2.TabIndex = 47;
            this.lblAT2.Text = "label12";
            // 
            // lblAT1
            // 
            this.lblAT1.AutoSize = true;
            this.lblAT1.Location = new System.Drawing.Point(170, 63);
            this.lblAT1.Name = "lblAT1";
            this.lblAT1.Size = new System.Drawing.Size(41, 13);
            this.lblAT1.TabIndex = 46;
            this.lblAT1.Text = "label13";
            // 
            // lblP5
            // 
            this.lblP5.AutoSize = true;
            this.lblP5.Location = new System.Drawing.Point(106, 153);
            this.lblP5.Name = "lblP5";
            this.lblP5.Size = new System.Drawing.Size(41, 13);
            this.lblP5.TabIndex = 56;
            this.lblP5.Text = "label14";
            // 
            // lblP4
            // 
            this.lblP4.AutoSize = true;
            this.lblP4.Location = new System.Drawing.Point(106, 133);
            this.lblP4.Name = "lblP4";
            this.lblP4.Size = new System.Drawing.Size(41, 13);
            this.lblP4.TabIndex = 55;
            this.lblP4.Text = "label15";
            // 
            // lblP3
            // 
            this.lblP3.AutoSize = true;
            this.lblP3.Location = new System.Drawing.Point(106, 110);
            this.lblP3.Name = "lblP3";
            this.lblP3.Size = new System.Drawing.Size(41, 13);
            this.lblP3.TabIndex = 54;
            this.lblP3.Text = "label11";
            // 
            // lblP2
            // 
            this.lblP2.AutoSize = true;
            this.lblP2.Location = new System.Drawing.Point(106, 86);
            this.lblP2.Name = "lblP2";
            this.lblP2.Size = new System.Drawing.Size(41, 13);
            this.lblP2.TabIndex = 53;
            this.lblP2.Text = "label12";
            // 
            // lblP1
            // 
            this.lblP1.AutoSize = true;
            this.lblP1.Location = new System.Drawing.Point(106, 63);
            this.lblP1.Name = "lblP1";
            this.lblP1.Size = new System.Drawing.Size(41, 13);
            this.lblP1.TabIndex = 52;
            this.lblP1.Text = "label13";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(7, 184);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(97, 13);
            this.label16.TabIndex = 59;
            this.label16.Text = "Avg Waiting Time :";
            // 
            // lblAvgWt
            // 
            this.lblAvgWt.AutoSize = true;
            this.lblAvgWt.Location = new System.Drawing.Point(106, 184);
            this.lblAvgWt.Name = "lblAvgWt";
            this.lblAvgWt.Size = new System.Drawing.Size(41, 13);
            this.lblAvgWt.TabIndex = 58;
            this.lblAvgWt.Text = "label17";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(164, 184);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(123, 13);
            this.label18.TabIndex = 61;
            this.label18.Text = "Avg. Turn Around Time :";
            // 
            // lblAvgTat
            // 
            this.lblAvgTat.AutoSize = true;
            this.lblAvgTat.Location = new System.Drawing.Point(293, 184);
            this.lblAvgTat.Name = "lblAvgTat";
            this.lblAvgTat.Size = new System.Drawing.Size(41, 13);
            this.lblAvgTat.TabIndex = 60;
            this.lblAvgTat.Text = "label19";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.lblAvgTat);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.lblAvgWt);
            this.panel1.Controls.Add(this.lblWT1);
            this.panel1.Controls.Add(this.lblWT2);
            this.panel1.Controls.Add(this.lblP5);
            this.panel1.Controls.Add(this.lblWT3);
            this.panel1.Controls.Add(this.lblP4);
            this.panel1.Controls.Add(this.lblWT4);
            this.panel1.Controls.Add(this.lblP3);
            this.panel1.Controls.Add(this.lblWT5);
            this.panel1.Controls.Add(this.lblP2);
            this.panel1.Controls.Add(this.lblTAT1);
            this.panel1.Controls.Add(this.lblP1);
            this.panel1.Controls.Add(this.lblTAT2);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.lblTAT3);
            this.panel1.Controls.Add(this.lblAT5);
            this.panel1.Controls.Add(this.lblTAT4);
            this.panel1.Controls.Add(this.lblAT4);
            this.panel1.Controls.Add(this.lblTAT5);
            this.panel1.Controls.Add(this.lblAT3);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.lblAT2);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.lblAT1);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.lblCT1);
            this.panel1.Controls.Add(this.lblBT5);
            this.panel1.Controls.Add(this.lblCT2);
            this.panel1.Controls.Add(this.lblBT4);
            this.panel1.Controls.Add(this.lblCT3);
            this.panel1.Controls.Add(this.lblBT3);
            this.panel1.Controls.Add(this.lblCT4);
            this.panel1.Controls.Add(this.lblBT2);
            this.panel1.Controls.Add(this.lblCT5);
            this.panel1.Controls.Add(this.lblBT1);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Location = new System.Drawing.Point(1, 211);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(469, 227);
            this.panel1.TabIndex = 62;
            // 
            // btnSJF
            // 
            this.btnSJF.Location = new System.Drawing.Point(123, 165);
            this.btnSJF.Name = "btnSJF";
            this.btnSJF.Size = new System.Drawing.Size(75, 23);
            this.btnSJF.TabIndex = 63;
            this.btnSJF.Text = "SJF";
            this.btnSJF.UseVisualStyleBackColor = true;
            this.btnSJF.Click += new System.EventHandler(this.btnSJF_Click);
            // 
            // sorted
            // 
            this.sorted.Location = new System.Drawing.Point(239, 165);
            this.sorted.Name = "sorted";
            this.sorted.Size = new System.Drawing.Size(75, 23);
            this.sorted.TabIndex = 64;
            this.sorted.Text = "Sorted";
            this.sorted.UseVisualStyleBackColor = true;
            // 
            // row
            // 
            this.row.Location = new System.Drawing.Point(356, 165);
            this.row.Name = "row";
            this.row.Size = new System.Drawing.Size(75, 23);
            this.row.TabIndex = 65;
            this.row.Text = "row";
            this.row.UseVisualStyleBackColor = true;
            // 
            // frmOsAlgorithm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(482, 450);
            this.Controls.Add(this.row);
            this.Controls.Add(this.sorted);
            this.Controls.Add(this.btnSJF);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.txtBT5);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtAT5);
            this.Controls.Add(this.txtBT4);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtAT4);
            this.Controls.Add(this.txtBT3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtAT3);
            this.Controls.Add(this.txtBT2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtAT2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtBT1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtAT1);
            this.Controls.Add(this.btnFCFS);
            this.Name = "frmOsAlgorithm";
            this.Text = "Os Algorithms";
            this.Load += new System.EventHandler(this.frmOsAlgorithm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnFCFS;
        private System.Windows.Forms.TextBox txtAT1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtBT1;
        private System.Windows.Forms.TextBox txtBT2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtAT2;
        private System.Windows.Forms.TextBox txtBT3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtAT3;
        private System.Windows.Forms.TextBox txtBT4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtAT4;
        private System.Windows.Forms.TextBox txtBT5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtAT5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblWT3;
        private System.Windows.Forms.Label lblWT2;
        private System.Windows.Forms.Label lblWT1;
        private System.Windows.Forms.Label lblWT5;
        private System.Windows.Forms.Label lblWT4;
        private System.Windows.Forms.Label lblTAT5;
        private System.Windows.Forms.Label lblTAT4;
        private System.Windows.Forms.Label lblTAT3;
        private System.Windows.Forms.Label lblTAT2;
        private System.Windows.Forms.Label lblTAT1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label lblCT5;
        private System.Windows.Forms.Label lblCT4;
        private System.Windows.Forms.Label lblCT3;
        private System.Windows.Forms.Label lblCT2;
        private System.Windows.Forms.Label lblCT1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label lblBT5;
        private System.Windows.Forms.Label lblBT4;
        private System.Windows.Forms.Label lblBT3;
        private System.Windows.Forms.Label lblBT2;
        private System.Windows.Forms.Label lblBT1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lblAT5;
        private System.Windows.Forms.Label lblAT4;
        private System.Windows.Forms.Label lblAT3;
        private System.Windows.Forms.Label lblAT2;
        private System.Windows.Forms.Label lblAT1;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label lblP5;
        private System.Windows.Forms.Label lblP4;
        private System.Windows.Forms.Label lblP3;
        private System.Windows.Forms.Label lblP2;
        private System.Windows.Forms.Label lblP1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblAvgWt;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblAvgTat;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnSJF;
        private System.Windows.Forms.Button sorted;
        private System.Windows.Forms.Button row;
    }
}

